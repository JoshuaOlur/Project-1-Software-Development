package edu.westga.cs3211.Pirate_Inventory_Ship_Manager.view;

import edu.westga.cs3211.Pirate_Inventory_Ship_Manager.viewmodel.LoginViewModel;
import javafx.fxml.FXML;
import javafx.scene.control.Button;

import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;

/**
 * The Class CodeBehind.
 * 
 * @author CS 3211
 * @version Fall 2025
 */
public class LoginCodeBehind {

	@FXML
	private TextField nameTextField;

	@FXML
	private Button submitButton;

	@FXML
	private Label greetingLabel;
	
	@FXML
    private TextArea namesTextArea;

	private LoginViewModel viewModel;

	/**
	 * Instantiates a new greeting code behind.
	 * 
	 * @precondition none
	 * @precondition none
	 */
	public LoginCodeBehind() {
		this.viewModel = new LoginViewModel();
	}

	@FXML
	void initialize() {

		this.bindComponentsToViewModel();
	}

	private void bindComponentsToViewModel() {
		this.greetingLabel.textProperty().bind(this.viewModel.greetingProperty());
		this.nameTextField.textProperty().bindBidirectional(this.viewModel.nameProperty());
		this.namesTextArea.textProperty().bind(this.viewModel.allNamesProperty());
	}

	@FXML
	void handleSubmit() {

		this.viewModel.sayGreeting();

	}

}
